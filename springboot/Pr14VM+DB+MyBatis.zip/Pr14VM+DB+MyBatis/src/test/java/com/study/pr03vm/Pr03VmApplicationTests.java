package com.study.pr03vm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pr03VmApplicationTests {

    @Test
    void contextLoads() {
    }

}
